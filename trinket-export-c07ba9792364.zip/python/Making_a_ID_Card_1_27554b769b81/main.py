name='Aarav Agarwal'
dob='10/19/2014'
phone=1234567890
IDno='012345'
print('----------------------------------------------------------------')
print('Name - '+name)
print('Date of Birth - '+dob)
print('Phone - '+str(phone))
print('ID# - '+IDno )
print('----------------------------------------------------------------')