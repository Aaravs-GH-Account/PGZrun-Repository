import turtle
pencil=turtle.Turtle()
paper=turtle.Screen()
#bg=input('What background color do you want?')
#pc=input('What pencil color do you want?')
paper.bgcolor('white')
pencil.color('black')
pencil.shape('turtle')
pencil.width(5)
pencil.speed(10000000000000)
#Star Drawing
for i in range(10):
  pencil.color('black')
  for i in range(12):
    pencil.forward(100)
    pencil.right(131)
  pencil.color('white')
  pencil.up()
  pencil.goto(0,0)
  pencil.down()
  pencil.width(10)
  pencil.setheading(0)
  for i in range(12):
    pencil.forward(100)
    pencil.right(131)
  pencil.width(5)