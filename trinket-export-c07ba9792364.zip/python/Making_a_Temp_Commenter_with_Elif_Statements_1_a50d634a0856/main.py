var=int(input('What is the temperature outside (farenheit)?'))
if var>90 and var<141:
  print("It's super hot!🔥")
elif var>69 and var<91:
  print("It's hot!🥵")
elif var>49 and var<70:
  print("It's the perfect temprature outside!😀")
elif var>29 and var<50:
  print("It's cold!🥶")
elif var>-27 and var<30:
  print("It's super cold!❄️")
elif var<-27:
  print('TOO. COLD. TO. PROCESS.😱')
else:
  print('TOO. HOT. TO. PROCESS.😱')