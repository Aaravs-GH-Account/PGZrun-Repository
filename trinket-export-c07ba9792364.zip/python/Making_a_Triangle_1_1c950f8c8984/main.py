import turtle
pencil=turtle.Turtle()
pencil.shape("turtle")
pencil.forward(120)
pencil.left(120)
pencil.forward(120)
pencil.left(120)
pencil.forward(120)
pencil.left(120)